import random

# QUIZ QUESTIONS (Add more if you want)
questions = [
    {
        "q": "What is the output of 5 + 7?",
        "options": ["10", "12", "13", "14"],
        "answer": "12"
    },
    {
        "q": "Who invented Python?",
        "options": ["Guido van Rossum", "James Gosling", "Dennis Ritchie", "Elon Musk"],
        "answer": "Guido van Rossum"
    },
    {
        "q": "What is the capital of India?",
        "options": ["Mumbai", "Delhi", "Kolkata", "Chennai"],
        "answer": "Delhi"
    },
    {
        "q": "Which of the following is a programming language?",
        "options": ["Python", "Banana", "Table", "India"],
        "answer": "Python"
    },
    {
        "q": "What does RAM stand for?",
        "options": ["Read Accept Memory", "Random Access Memory", "Run After Memory", "None"],
        "answer": "Random Access Memory"
    }
]

def shuffle_questions(q_list):
    random.shuffle(q_list)
    for q in q_list:
        random.shuffle(q["options"])

def quiz_game():
    print("\n===== WELCOME TO THE QUIZ GAME =====")
    print("Rules:")
    print("• Each correct answer gives +1 point")
    print("• No negative marking")
    print("• Options are randomized every time\n")

    score = 0
    shuffle_questions(questions)

    # Ask all questions
    for idx, q in enumerate(questions, start=1):
        print(f"\nQuestion {idx}: {q['q']}")
        for i, opt in enumerate(q["options"], start=1):
            print(f" {i}. {opt}")

        ans = input("Enter Option Number: ")

        # Validate input
        if ans.isdigit():
            ans_index = int(ans) - 1
            if 0 <= ans_index < len(q["options"]):
                if q["options"][ans_index] == q["answer"]:
                    print("✔ Correct!")
                    score += 1
                else:
                    print("✘ Wrong!")
                    print("Correct Answer:", q["answer"])
            else:
                print("Invalid option!")
        else:
            print("Invalid input!")

    print("\n===== QUIZ FINISHED =====")
    print("Your Score:", score, "/", len(questions))

    # Performance remarks
    if score == len(questions):
        print("🌟 Excellent! Perfect Score!")
    elif score >= len(questions) * 0.7:
        print("👍 Great job! Keep it up!")
    elif score >= len(questions) * 0.4:
        print("🙂 Not bad, but you can improve.")
    else:
        print("😢 Try again, practice makes perfect!")

# Start the game
quiz_game()
