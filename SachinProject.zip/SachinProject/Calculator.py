import numpy as np

def show_result(value):
    print("\n|==============================|")
    print("|        FINAL RESULT          |")
    print("|==============================|")
    print(f"|       >>> {value} <<<           |")
    print("|==============================|\n")

def menu():
    print("\n===== Advanced NumPy Calculator =====")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")
    print("5. Power (a^b)")
    print("6. Square Root")
    print("7. Percentage (a% of b)")
    print("8. Exit")

while True:
    menu()
    choice = input("Choose option (1-8): ")

    if choice == "8":
        print("Thank you for using the calculator!")
        break

    # Addition, Subtraction, Multiplication (same logic)
    if choice in ["1", "2", "3"]:
        try:
            a = float(input("Enter first number: "))
            b = float(input("Enter second number: "))

            # Perform initial operation
            if choice == "1":
                result = a + b
            elif choice == "2":
                result = a - b
            elif choice == "3":
                result = a * b

            # BEFORE showing result → ask if want more numbers
            while True:
                more = input("Press 1 to add more numbers, or press Enter to show result: ")

                if more == "1":
                    next_num = float(input("Enter next number: "))

                    if choice == "1":
                        result += next_num
                    elif choice == "2":
                        result -= next_num
                    elif choice == "3":
                        result *= next_num
                else:
                    break

            show_result(result)
            input("Press Enter to return to home...")

        except ValueError:
            print("Invalid input!")

    # Division, Power, Percentage
    elif choice in ["4", "5", "7"]:
        try:
            a = float(input("Enter first number: "))
            b = float(input("Enter second number: "))

            if choice == "4":
                if b == 0:
                    show_result("Error! Division by Zero")
                else:
                    show_result(np.divide(a, b))

            elif choice == "5":
                show_result(np.power(a, b))

            elif choice == "7":
                show_result((a / 100) * b)

            input("Press Enter to return to home...")

        except ValueError:
            print("Invalid input!")

    # Square root
    elif choice == "6":
        try:
            x = float(input("Enter number: "))
            if x < 0:
                show_result("Error! Negative number")
            else:
                show_result(np.sqrt(x))

            input("Press Enter to return to home...")

        except ValueError:
            print("Invalid input!")

    else:
        print("Invalid choice! Try again...")
