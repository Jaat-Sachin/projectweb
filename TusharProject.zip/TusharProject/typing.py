import time
import random
import os

# ------------------------------
#  Sample Paragraphs
# ------------------------------
PARAGRAPHS = [
    "Python is a powerful programming language used for web development, data science, and automation.",
    "The quick brown fox jumps over the lazy dog and runs into the green forest near the river.",
    "Artificial intelligence is changing the world by solving complex problems faster than humans.",
    "Typing speed improves with regular practice and proper posture while sitting in front of a computer.",
    "Technology plays a major role in education, communication, and improving the quality of life."
]

# ------------------------------
#  Clear screen utility
# ------------------------------
def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

# ------------------------------
#  Typing Test Function
# ------------------------------
def typing_test():
    clear()
    print("========== TYPING SPEED TEST ==========\n")
    
    paragraph = random.choice(PARAGRAPHS)
    print("Type the following paragraph:\n")
    print(paragraph)
    print("\n---------------------------------------")
    input("Press ENTER to start typing... ")
    
    clear()
    print("Start typing below:\n")
    print(paragraph)
    print("\n---------------------------------------")

    start_time = time.time()
    typed = input("\nYour typing:\n> ")
    end_time = time.time()

    # ------------------------------
    #  Calculations
    # ------------------------------
    time_taken = end_time - start_time
    time_minutes = time_taken / 60

    words_typed = len(typed.split())
    wpm = int(words_typed / time_minutes)

    # Accuracy
    correct_chars = 0
    errors = 0

    for i in range(min(len(paragraph), len(typed))):
        if paragraph[i] == typed[i]:
            correct_chars += 1
        else:
            errors += 1

    errors += abs(len(paragraph) - len(typed))   # extra chars count as errors

    accuracy = (correct_chars / len(paragraph)) * 100

    # ------------------------------
    #  Results
    # ------------------------------
    clear()
    print("========== RESULT ==========\n")
    print(f"Time Taken      : {time_taken:.2f} seconds")
    print(f"Words Typed     : {words_typed}")
    print(f"WPM (Speed)     : {wpm} words per minute")
    print(f"Accuracy        : {accuracy:.2f}%")
    print(f"Errors          : {errors}\n")

    print("=========================================\n")
    input("Press ENTER to return to main menu...")

# ------------------------------
#  Main Menu
# ------------------------------
def main():
    while True:
        clear()
        print("====================================")
        print("        PYTHON TYPING MASTER        ")
        print("====================================")
        print("1. Start Typing Test")
        print("2. Exit")
        print("====================================")

        choice = input("Choose an option (1/2): ")

        if choice == "1":
            typing_test()
        elif choice == "2":
            clear()
            print("Thank you for using Typing Master!")
            break
        else:
            input("Invalid input! Press ENTER to try again.")

# ------------------------------
# Run the App
# ------------------------------
if __name__ == "__main__":
    main()
